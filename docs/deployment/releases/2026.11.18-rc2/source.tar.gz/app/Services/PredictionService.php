<?php

namespace App\Services;

use App\Models\AIChat;
use App\Models\Announcement;
use App\Models\ClimateRecord;
use App\Models\ExternalWeatherData;
use App\Models\FarmerProfile;
use App\Models\Notification;
use App\Models\PlantingAdvisory;
use App\Models\RiceProduction;
use App\Models\User;
use App\Services\AI\FarmerAnswerStyle;
use App\Services\AI\GroqChatService;
use App\Services\AI\IntentDetectionService;
use App\Services\AI\KnowledgeBaseService;
use App\Services\AI\RoleAssistantService;
use App\Services\Prediction\PredictionDateValidator;
use App\Services\Prediction\RiceYieldPredictionService;
use App\Support\ActiveFarm;
use App\Support\FarmSize;
use Carbon\CarbonImmutable;
use Illuminate\Support\Arr;

class PredictionService
{
    public function __construct(
        private readonly DecisionSupportService $decisionSupport,
        private readonly IntentDetectionService $intentDetector,
        private readonly KnowledgeBaseService $knowledgeBase,
        private readonly GroqChatService $groqChat,
        private readonly RoleAssistantService $roleAssistant,
        private readonly PredictionDateValidator $dateValidator,
        private readonly RiceYieldPredictionService $riceYield,
    ) {}

    /**
     * Whether the date implied by the question (or the default target date,
     * if none is mentioned) is invalid — used by AIOrchestratorService to
     * check date validity before deciding whether to ask for a missing
     * farm area, so an already-invalid date isn't masked by an area
     * clarification prompt for a request that could never succeed anyway.
     */
    public function hasInvalidTargetDate(string $question): bool
    {
        $targetDate = $this->parseTargetDateFromQuestion($question) ?? PredictionDateValidator::defaultTargetDate();

        return $this->dateValidator->validate($targetDate) !== null;
    }

    public function answer(User $user, string $question): array
    {
        $startedAt = microtime(true);
        $memory = $this->conversationMemory($user);
        $language = $this->intentDetector->detectLanguage($question, $memory, $user->aiLanguageCode());
        $intentResult = $this->intentDetector->detect($question, $memory);
        $intent = $intentResult['intent'];

        if (! $intentResult['requires_prediction']) {
            return $this->answerWithoutPrediction($user, $question, $intent, $language, $memory, $intentResult, $startedAt);
        }

        $targetDate = $this->parseTargetDateFromQuestion($question) ?? PredictionDateValidator::defaultTargetDate();

        if ($message = $this->dateValidator->validate($targetDate)) {
            return $this->validationResponse($intent, $language, $memory, $startedAt, $message, $targetDate);
        }

        $numbers = $this->numbersFrom($question);
        $memoryText = $question.' '.implode(' ', $memory['recent_questions'] ?? []);
        $conditions = $this->conditionsFrom($memoryText);
        $profile = $user->farmerProfile ?: FarmerProfile::query()->where('user_id', $user->id)->first();
        $activeFarm = $user->role === User::ROLE_FARMER ? ActiveFarm::current($user) : null;

        $farmType = $conditions['farm_type'] ?? (string) ($activeFarm?->farm_type ?? $profile?->farm_type ?? FarmerProfile::FARM_TYPE_RAINFED);
        $areaOverride = $numbers['area'] ?? null;
        $manualOverrides = array_filter([
            'rainfall' => $numbers['rainfall'] ?? null,
            'temp_avg' => $numbers['temperature'] ?? $conditions['temperature'] ?? null,
            'humidity' => $numbers['humidity'] ?? null,
            'wind_speed' => $numbers['wind_speed'] ?? null,
            'temp_range' => $numbers['temp_range'] ?? null,
            'season' => $conditions['season'] ?? null,
        ], fn ($value) => $value !== null);

        $sharedYieldResult = $this->riceYield->predictForUser($targetDate, $farmType, $areaOverride, $user, $manualOverrides);
        $engineResult = $sharedYieldResult['engine_result'];

        // No model result means no prediction, and nothing is estimated in its place. Advice that does not
        // need a yield (e.g. irrigation from supplied weather) can still be given; a yield question, or advice
        // without enough weather data, cannot.
        $decisionLacksData = (bool) data_get($engineResult, 'decision_support.insufficient_data', false);
        if (! ($sharedYieldResult['success'] ?? false) && ($decisionLacksData || $intent === IntentDetectionService::RICE_YIELD_PREDICTION)) {
            $message = $this->isTagalog($language)
                ? 'Hindi pa available ang prediksyon ng ani dahil kulang ang mga napatunayang datos o hindi gumagana ang prediction system. Walang tantiyang ginawa. Subukan muli mamaya.'
                : 'A rice-yield prediction is not available right now because verified input data is incomplete or the prediction service is unavailable. No estimate was made. Please try again later.';

            return $this->textResponse($message, $intent, $language, $memory, $startedAt, [
                'source_type' => 'System',
                'source_name' => 'iClimate Prediction System',
                'confidence_score' => 0,
                'intent_detection' => $intentResult,
            ]);
        }

        $context = [
            ...$engineResult['model_input'],
            'barangay' => (string) ($activeFarm?->barangay ?? $profile?->barangay ?? $user->barangay ?? ''),
            'farm_context' => $activeFarm ? [
                'name' => $activeFarm->farm_name,
                'size' => FarmSize::describe($activeFarm),
                'size_method' => $activeFarm->farm_size_method,
                'estimate_range' => $activeFarm->farm_size_estimate_range,
            ] : null,
            'source_notes' => $this->sourceNotes($numbers, $conditions, $targetDate->startOfMonth()),
        ];

        $yield = $sharedYieldResult;
        unset($yield['engine_result']);
        $apiError = $engineResult['api_error'];

        $weather = [
            'predicted_weather' => $engineResult['weather_label'],
            'rainfall' => $context['rainfall'],
            'temperature' => $context['temp_avg'],
            'humidity' => $context['humidity'],
            'wind_speed' => $context['wind_speed'],
            'season' => $context['season'],
            'confidence' => data_get($engineResult['weather'], 'confidence.value'),
            'source_type' => 'Trained Model',
            'source_name' => 'iClimate Weather System',
            'source_credit' => 'Weather estimate for the month, made by the iClimate weather system.',
        ];

        $predictedYield = Arr::get($yield, 'predicted_yield');

        $decision = $this->decisionSupport->evaluate([
            ...$context,
            'predicted_yield' => $predictedYield,
            'predicted_weather' => $weather['predicted_weather'],
        ]);

        $warnings = $this->normalizeWarnings([], $decision);
        $quality = $this->predictionQuality($context, $yield, $apiError);
        $insights = $this->insights($intent, $context, $yield, $decision, $warnings, $quality, $language);
        $explanation = $this->explanation($weather, $yield, $insights, $apiError, $language);
        $confidence = $this->adjustedConfidence($yield, $decision, $quality);
        $answer = $this->composeAnswer($intent, $weather, $yield, $decision, $warnings, $insights, $explanation, 'Machine Learning + Decision Support', $confidence, $language);
        $groqFallback = $this->groqPredictionFallback($user, $question, $intent, $language, $memory, $context, $weather, $yield, $decision, $warnings, $quality, $apiError);

        if ($groqFallback) {
            $answer = $groqFallback['answer'];
        }

        // Farmers get the short Answer → Reason → Action version unless they asked why or for details;
        // the full report above is kept as this chat's details for a "Why?" follow-up.
        $brief = $user->role === User::ROLE_FARMER && ! FarmerAnswerStyle::asksForDetails($question)
            ? FarmerAnswerStyle::brief($intent, $decision, $weather, $yield, $warnings, $insights, (string) ($context['farm_type'] ?? ''), $this->isTagalog($language))
            : null;
        if ($brief !== null) {
            // 'brief' tells the chat UI to skip the raw prediction cards; it lives in memory because that column is saved and returned.
            $memory = [...$memory, 'details' => $answer, 'brief' => true];
            $answer = $brief;
        }

        return [
            'intent' => $intent,
            'answer' => $answer,
            'brief' => $brief !== null,
            'source_type' => $groqFallback ? 'Machine Learning + Generative AI' : 'Machine Learning',
            // With no model result there is no yield source to name: the advice then rests on the weather rules alone.
            'source_name' => $groqFallback
                ? ($yield['source_name'] ?? 'iClimate Decision Support').' + '.$groqFallback['source_name']
                : ($yield['source_name'] ?? 'iClimate Decision Support'),
            'source_url' => null,
            'source_credit' => $groqFallback
                ? 'Prediction values came from trained iClimate models/rules; explanation was assisted by Groq.'
                : 'Prediction values came from trained iClimate models and local decision-support rules.',
            'language' => $language,
            'memory' => $memory,
            'prediction_result' => [
                'decision_support' => $decision,
                'input_features' => $context,
                'quality' => $quality,
                'insights' => $insights,
                'conversation_memory' => $memory,
                'api_error' => $apiError,
                'rice_yield_prediction' => $yield,
                'authoritative_yield_service' => 'RiceYieldPredictionService',
                'model_version' => $yield['model_version'] ?? null,
                'feature_order' => $yield['feature_order'] ?? [],
                'intent_detection' => $intentResult,
                'target_date' => $targetDate->toDateString(),
                'generative_ai' => $groqFallback ? [
                    'provider' => 'Groq',
                    'model' => $groqFallback['model'],
                    'usage' => $groqFallback['usage'],
                    'reason' => 'Trained model output was unavailable or low-confidence, so Groq explained the iClimate result.',
                ] : null,
                'answer_source' => 'Prediction values came from trained machine-learning models and iClimate decision rules.',
                'source_credit' => $groqFallback
                    ? 'Prediction values came from trained iClimate models/rules; explanation was assisted by Groq.'
                    : 'Prediction values came from trained iClimate models and local decision-support rules.',
            ],
            'weather_prediction' => $weather,
            'rice_yield_prediction' => $yield,
            'planting_recommendation' => $decision['planting'],
            'irrigation_recommendation' => $decision['irrigation'],
            'warnings' => $warnings,
            'explanation' => $explanation,
            'confidence_score' => $confidence,
            'response_time_ms' => (int) round((microtime(true) - $startedAt) * 1000),
        ];
    }

    private function validationResponse(string $intent, string $language, array $memory, float $startedAt, string $message, CarbonImmutable $targetDate): array
    {
        return [
            'intent' => $intent,
            'answer' => $message,
            'source_type' => 'Validation',
            'source_name' => 'iClimate Date Validation',
            'source_url' => null,
            'source_credit' => 'Source: iClimate Date Validation',
            'language' => $language,
            'memory' => [
                ...$memory,
                'last_answer_source' => 'Validation',
                'last_answer_intent' => $intent,
            ],
            'prediction_result' => [
                'validation_error' => true,
                'target_date' => $targetDate->toDateString(),
                'reason' => $message,
            ],
            'weather_prediction' => null,
            'rice_yield_prediction' => null,
            'planting_recommendation' => null,
            'irrigation_recommendation' => null,
            'warnings' => [],
            'explanation' => $message,
            'confidence_score' => 0,
            'response_time_ms' => (int) round((microtime(true) - $startedAt) * 1000),
        ];
    }

    private function parseTargetDateFromQuestion(string $question): ?CarbonImmutable
    {
        $text = str($question)->lower()->toString();

        if (str_contains($text, 'next month') || str_contains($text, 'susunod na buwan')) {
            return \App\Support\BusinessClock::now()->toImmutable()->addMonthNoOverflow();
        }

        if (str_contains($text, 'this month') || str_contains($text, 'ngayong buwan')) {
            return \App\Support\BusinessClock::now()->toImmutable();
        }

        if (preg_match('/\b(\d{4})-(\d{1,2})(?:-(\d{1,2}))?\b/', $question, $match)) {
            try {
                return CarbonImmutable::createFromDate((int) $match[1], (int) $match[2], (int) ($match[3] ?? 1));
            } catch (\Throwable) {
                return null;
            }
        }

        $months = [
            'january' => 1, 'february' => 2, 'march' => 3, 'april' => 4, 'may' => 5, 'june' => 6,
            'july' => 7, 'august' => 8, 'september' => 9, 'october' => 10, 'november' => 11, 'december' => 12,
            'jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4, 'jun' => 6, 'jul' => 7, 'aug' => 8,
            'sep' => 9, 'sept' => 9, 'oct' => 10, 'nov' => 11, 'dec' => 12,
        ];

        if (preg_match('/\b('.implode('|', array_keys($months)).')\b(?:\s+(\d{1,2})(?!\d))?,?\s*(\d{4})?/i', $text, $match)) {
            $month = $months[strtolower($match[1])];
            $day = ! empty($match[2]) ? (int) $match[2] : 1;
            $hasYear = ! empty($match[3]);
            $year = $hasYear ? (int) $match[3] : \App\Support\BusinessClock::now()->toImmutable()->year;

            try {
                $date = CarbonImmutable::createFromDate($year, $month, $day);
            } catch (\Throwable) {
                return null;
            }

            if (! $hasYear && $date->toDateString() <= \App\Support\BusinessClock::today()->toDateString()) {
                $date = $date->addYear();
            }

            return $date;
        }

        return null;
    }

    private function groqPredictionFallback(User $user, string $question, string $intent, string $language, array $memory, array $context, array $weather, array $yield, array $decision, array $warnings, array $quality, ?string $apiError): ?array
    {
        if (! $this->shouldAskGroqForPredictionFallback($quality, $apiError, false)) {
            return null;
        }

        return $this->groqChat->predictionFallback($user, $question, $intent, $language, $memory, [
            'inputs_used' => Arr::only($context, ['rainfall', 'temp_avg', 'humidity', 'wind_speed', 'season', 'farm_type', 'area', 'barangay']),
            'weather_prediction' => $weather,
            'rice_yield_prediction' => $yield,
            'risk' => $decision['risk'] ?? null,
            'score' => $decision['score'] ?? null,
            'planting_recommendation' => $decision['planting'] ?? null,
            'irrigation_recommendation' => $decision['irrigation'] ?? null,
            'yield_advisory' => $decision['yield'] ?? null,
            'warnings' => $warnings,
            'quality' => $quality,
            'python_api_error' => $apiError,
            'fallback_used' => $apiError !== null,
        ]);
    }

    private function shouldAskGroqForPredictionFallback(array $quality, ?string $apiError, bool $isFallback): bool
    {
        return $this->groqChat->available()
            && (
                $apiError !== null
                || $isFallback
                || (($quality['score'] ?? 100) < 70)
            );
    }

    private function answerWithoutPrediction(User $user, string $question, string $intent, string $language, array $memory, array $intentResult, float $startedAt): array
    {
        if ($this->shouldUseLocalSystemAnswer($intent, $question)) {
            return $this->textResponse($this->localSystemAnswer($intent, $question, $language), $intent, $language, $memory, $startedAt, [
                'source_type' => 'Knowledge Base',
                'source_name' => 'Climora AI',
                'source_url' => null,
                'confidence_score' => 82,
                'intent_detection' => $intentResult,
            ]);
        }

        if ($domainAnswer = $this->domainRecordAnswer($user, $question, $intent, $language)) {
            return $this->textResponse($domainAnswer['answer'], $intent, $language, $memory, $startedAt, [
                'source_type' => 'Knowledge Base',
                'source_name' => $domainAnswer['source_name'],
                'source_url' => null,
                'confidence_score' => $domainAnswer['confidence'],
                'intent_detection' => $intentResult,
            ]);
        }

        if ($record = $this->knowledgeBase->search($question, $intent)) {
            return $this->textResponse((string) $record->answer, $intent, $language, $memory, $startedAt, [
                'source_type' => 'Knowledge Base',
                'source_name' => $record->source_name ?: 'iClimate Knowledge Base',
                'source_url' => $record->source_url,
                'confidence_score' => (float) ($record->confidence ?? 82),
                'knowledge_base_id' => $record->id,
                'intent_detection' => $intentResult,
            ]);
        }

        if ($groqAnswer = $this->groqChat->answer($user, $question, $intent, $language, $memory, $this->assistantContextForGroq($user))) {
            return $this->textResponse($groqAnswer['answer'], $intent, $language, $memory, $startedAt, [
                'source_type' => 'Generative AI',
                'source_name' => $groqAnswer['source_name'],
                'source_url' => null,
                'confidence_score' => $groqAnswer['confidence'],
                'intent_detection' => $intentResult,
                'generative_ai' => [
                    'provider' => 'Groq',
                    'model' => $groqAnswer['model'],
                    'usage' => $groqAnswer['usage'],
                ],
            ]);
        }

        if ($builtIn = $this->knowledgeBase->builtInAnswer($question, $intent, $language)) {
            return $this->textResponse($builtIn['answer'], $intent, $language, $memory, $startedAt, [
                'source_type' => 'Knowledge Base',
                'source_name' => $builtIn['source_name'],
                'source_url' => null,
                'confidence_score' => $builtIn['confidence'],
                'intent_detection' => $intentResult,
            ]);
        }

        if (! $this->isSupportedNonPredictionQuestion($intent, $question)) {
            return $this->textResponse($this->unsupportedAnswer($language), $intent, $language, $memory, $startedAt, [
                'source_type' => 'System Scope',
                'source_name' => 'Climora AI',
                'source_url' => null,
                'confidence_score' => 80,
                'intent_detection' => $intentResult,
            ]);
        }

        $localAnswer = $this->localSystemAnswer($intent, $question, $language);

        return $this->textResponse($localAnswer, $intent, $language, $memory, $startedAt, [
            'source_type' => 'Knowledge Base',
            'source_name' => 'Climora AI',
            'source_url' => null,
            'confidence_score' => 76,
            'intent_detection' => $intentResult,
        ]);
    }

    private function shouldUseLocalSystemAnswer(string $intent, string $question): bool
    {
        $text = str($question)->lower()->toString();

        // "sino ka"/"ano ka" use word-boundary matching, not plain
        // substring — "ano ka" is otherwise a false-positive substring of
        // unrelated text like "paano kaba" ("p-AANO KA-ba"), which would
        // wrongly treat an out-of-scope question as a supported identity
        // question and answer it instead of rejecting it.
        if (preg_match('/\b(sino|ano)\s+ka\b/u', $text) === 1 || str($text)->contains([
            'who are you',
            'what are you',
            'tagalog',
            'filipino',
            'pilipino',
        ])) {
            return true;
        }

        return $intent === IntentDetectionService::SYSTEM_HELP
            && str($text)->contains([
                'how do you gather',
                'how do you get',
                'how do you collect',
                'where do you get',
                'weather source',
                'weather data source',
            ]);
    }

    private function conversationMemory(User $user): array
    {
        // Shared with the orchestrator, so the history is read once per message.
        return app(\App\Services\AI\ConversationContext::class)->recent($user);
    }

    private function domainRecordAnswer(User $user, string $question, string $intent, string $language): ?array
    {
        $text = str($question)->lower()->toString();

        if ($intent === IntentDetectionService::BARANGAY_INFO || str_contains($text, 'barangay')) {
            if ($answer = $this->roleAssistant->barangayAnswer($user, $question, $language)) {
                return $answer;
            }
        }

        $mentionsMaoReport = str_contains($text, 'how many farmer') || str_contains($text, 'registered farmer')
            || str_contains($text, 'production summary') || str_contains($text, 'generate report')
            || (str_contains($text, 'farmer') && str_contains($text, 'many'));

        if ($intent === IntentDetectionService::MAO_REPORTS || $mentionsMaoReport) {
            if ($user->role !== User::ROLE_MAO) {
                return [
                    'answer' => $this->roleAssistant->roleRestrictedMessage($language, User::ROLE_MAO, $user->role),
                    'source_name' => 'Climora AI',
                    'confidence' => 85,
                ];
            }

            if ($answer = $this->roleAssistant->maoAnswer($user, $question, $intent, $language)) {
                return $answer;
            }
        }

        if ($intent === IntentDetectionService::IT_SYSTEM_STATUS) {
            return ['answer' => str_contains($language, 'Tagalog') ? 'Ang system maintenance ay pinamamahalaan sa server.' : 'System maintenance is managed through protected server tools.', 'source_name' => 'Climora AI', 'confidence' => 85];
        }

        if ($intent === IntentDetectionService::ANNOUNCEMENT || str_contains($text, 'announcement')) {
            $announcement = Announcement::query()->where('status', 'Published')->latest()->first();

            if ($announcement) {
                return [
                    'answer' => 'Latest announcement: '.$announcement->title.'. '.$announcement->content,
                    'source_name' => 'iClimate Announcements',
                    'confidence' => 92,
                ];
            }
        }

        if ($intent === IntentDetectionService::NOTIFICATION || str_contains($text, 'notification')) {
            $notification = Notification::query()->where('user_id', $user->id)->latest()->first();

            if ($notification) {
                return [
                    'answer' => 'Latest notification: '.$notification->title.'. '.$notification->message,
                    'source_name' => 'iClimate Notifications',
                    'confidence' => 92,
                ];
            }
        }

        if ($intent === IntentDetectionService::CALENDAR || str_contains($text, 'calendar')) {
            $advisory = PlantingAdvisory::query()->where('status', 'Published')->latest()->first();

            if ($advisory) {
                return [
                    'answer' => 'Planting calendar guidance: '.$advisory->title.'. '.$advisory->content,
                    'source_name' => 'iClimate Planting Advisories',
                    'confidence' => 86,
                ];
            }
        }

        if ($intent === IntentDetectionService::USER_PROFILE || str_contains($text, 'profile')) {
            $farm = $user->role === User::ROLE_FARMER ? ActiveFarm::current($user) : null;
            $profile = $user->farmerProfile;
            $answer = $farm
                ? 'Your selected farm, '.$farm->farm_name.', is in barangay '.$farm->barangay.', with size '.FarmSize::describe($farm)['text'].', and farm type '.($farm->farm_type ?: 'not added').'.'
                : ($profile
                    ? 'Your profile shows barangay '.$profile->barangay.', farm area '.$profile->farm_area.' hectares, and farm type '.$profile->farm_type.'.'
                    : 'No farmer profile is linked to your account yet. Add farm area, barangay, and farm type to improve iClimate recommendations.');

            return [
                'answer' => $answer,
                'source_name' => 'iClimate User Profile',
                'confidence' => 90,
            ];
        }

        return null;
    }

    private function assistantContextForGroq(User $user): array
    {
        $profile = $user->farmerProfile;
        $farm = $user->role === User::ROLE_FARMER ? ActiveFarm::current($user) : null;
        $barangay = $farm?->barangay ?: ($profile?->barangay ?: $user->barangay);
        $latestWeather = ExternalWeatherData::query()->latest('fetched_at')->first();
        $latestClimate = ClimateRecord::query()->latest('record_date')->first();
        $latestProduction = RiceProduction::query()
            ->when($barangay, fn ($query) => $query->where('barangay', $barangay))
            ->latest('year')
            ->first() ?: RiceProduction::query()->latest('year')->first();
        $latestAdvisory = PlantingAdvisory::query()
            ->active()
            ->forBarangay($barangay)
            ->latest('published_at')
            ->first();
        $latestAnnouncement = Announcement::query()->where('status', 'Published')->latest()->first();
        $latestNotification = Notification::query()->where('user_id', $user->id)->latest()->first();

        return [
            'current_user' => [
                'role' => $user->role,
                'barangay' => $barangay,
                'farm_name' => $farm?->farm_name,
                'farm_area_hectares' => $farm?->modelArea() ?? $profile?->farm_area,
                'farm_size_method' => $farm?->farm_size_method,
                'farm_size_estimate_range' => $farm?->farm_size_estimate_range,
                'farm_type' => $farm?->farm_type ?? $profile?->farm_type,
            ],
            'latest_weather_forecast' => $latestWeather ? [
                'source' => $latestWeather->source,
                'location' => $latestWeather->location_name,
                'forecast_date' => $latestWeather->forecast_date?->toDateString(),
                'temperature_c' => $latestWeather->temperature,
                'rainfall_mm' => $latestWeather->rainfall_mm,
                'humidity_percent' => $latestWeather->humidity,
                'wind_speed' => $latestWeather->wind_speed,
                'precipitation_probability' => $latestWeather->precipitation_probability,
                'fetched_at' => $latestWeather->fetched_at?->toDateTimeString(),
            ] : null,
            'latest_climate_record' => $latestClimate ? [
                'record_date' => $latestClimate->record_date?->toDateString(),
                'rainfall_mm' => $latestClimate->rainfall,
                'temperature_c' => $latestClimate->temperature,
                'humidity_percent' => $latestClimate->humidity,
                'wind_speed' => $latestClimate->wind_speed,
                'season' => $latestClimate->season,
                'source' => $latestClimate->source,
            ] : null,
            'latest_rice_production' => $latestProduction ? [
                'barangay' => $latestProduction->barangay,
                'year' => $latestProduction->year,
                'season' => $latestProduction->season,
                'irrigation_type' => $latestProduction->irrigation_type,
                'yield_per_hectare' => $latestProduction->yield_per_hectare,
                'area_hectares' => $latestProduction->area_hectares,
                'total_production' => $latestProduction->total_production,
            ] : null,
            'active_planting_advisory' => $latestAdvisory ? [
                'title' => $latestAdvisory->title,
                'summary' => $latestAdvisory->summary,
                'message' => $latestAdvisory->message,
                'recommended_action' => $latestAdvisory->recommended_action,
                'severity' => $latestAdvisory->severity,
                'target_barangay' => $latestAdvisory->targetLabel(),
                'source' => $latestAdvisory->source,
                'published_at' => $latestAdvisory->published_at?->toDateTimeString(),
            ] : null,
            'latest_announcement' => $latestAnnouncement ? [
                'title' => $latestAnnouncement->title,
                'content' => str($latestAnnouncement->content)->limit(400)->toString(),
                'published_at' => $latestAnnouncement->published_at?->toDateTimeString(),
            ] : null,
            'latest_notification' => $latestNotification ? [
                'title' => $latestNotification->title,
                'message' => $latestNotification->message,
                'created_at' => $latestNotification->created_at?->toDateTimeString(),
            ] : null,
            'record_counts' => [
                'climate_records' => ClimateRecord::query()->count(),
                'rice_productions' => RiceProduction::query()->count(),
                'weather_forecasts' => ExternalWeatherData::query()->count(),
                'active_advisories' => PlantingAdvisory::query()->active()->forBarangay($barangay)->count(),
            ],
        ];
    }

    private function isSupportedNonPredictionQuestion(string $intent, string $question): bool
    {
        $text = str($question)->lower()->toString();

        // SYSTEM_HELP is deliberately excluded from this always-supported
        // list: genuine system-help questions are already answered earlier
        // in the chain (shouldUseLocalSystemAnswer, the seeded Knowledge
        // Base, or builtInAnswer's specific keyword/answer pairs). If a
        // SYSTEM_HELP-classified question reaches this point without any
        // of those matching, that's a signal it probably isn't a real,
        // answerable system question — it should still be judged by the
        // keyword check below rather than automatically approved.
        if (in_array($intent, [
            IntentDetectionService::ANNOUNCEMENT,
            IntentDetectionService::NOTIFICATION,
            IntentDetectionService::CALENDAR,
            IntentDetectionService::USER_PROFILE,
            IntentDetectionService::FARMING_ADVISORY,
            IntentDetectionService::GENERAL_AGRICULTURE,
            IntentDetectionService::BARANGAY_INFO,
            IntentDetectionService::MAO_REPORTS,
            IntentDetectionService::IT_SYSTEM_STATUS,
            IntentDetectionService::GENERAL_CONVERSATION,
        ], true)) {
            return true;
        }

        return str($text)->contains([
            'iclimate',
            'weather prediction',
            'rice yield',
            'planting advisory',
            'community feed',
            'notification',
            'announcement',
            'profile',
            'dashboard',
            'feedback',
            'climate record',
            'heat map',
            'report',
            'barangay',
            'database',
            'server',
            'backup',
            'maintenance',
            'fertilizer',
            'soil',
            'pest',
            'disease',
            'random forest',
            'rmse',
        ]);
    }

    private function unsupportedAnswer(string $language): string
    {
        if (str_contains($language, 'Tagalog')) {
            return 'Makakatulong ako tungkol sa iClimate lang: weather prediction, rice yield prediction, planting at irrigation advice, climate risk, fertilizer, pest at disease, soil, barangay information, announcements, notifications, profile, calendar, reports, at kung paano gamitin ang system.';
        }

        return 'I can help with iClimate only: weather prediction, rice yield prediction, planting and irrigation advice, climate risk, fertilizer, pest and disease guidance, soil information, barangay information, announcements, notifications, profile, calendar, reports, and how to use the system.';
    }

    private function localSystemAnswer(string $intent, string $question, string $language): string
    {
        $text = str($question)->lower()->toString();

        if (str($text)->contains(['tagalog', 'filipino', 'pilipino'])) {
            return 'Oo, puwede akong sumagot sa Tagalog o mixed Tagalog-English. Itanong mo lang ang kailangan mo tungkol sa iClimate, panahon, ani, pagtatanim, patubig, advisory, o problema sa palay.';
        }

        if (preg_match('/\b(sino|ano)\s+ka\b/u', $text) === 1 || str($text)->contains(['who are you', 'what are you'])) {
            return str_contains($language, 'Tagalog')
                ? 'Ako si Climora AI, ang iClimate rice guidance assistant para sa Lian, Batangas. Tumutulong ako sa tanong tungkol sa panahon, ani ng palay, pagtatanim, patubig, advisories, climate risk, at paggamit ng iClimate system.'
                : 'I am Climora AI, the iClimate rice guidance assistant for Lian, Batangas. I help with weather, rice yield, planting, irrigation, advisories, climate risk, and using the iClimate system.';
        }

        if ($intent === IntentDetectionService::GENERAL_CONVERSATION) {
            if (str_contains($text, 'thank') || str_contains($text, 'salamat')) {
                return str_contains($language, 'Tagalog')
                    ? 'Walang anuman! Tanong lang kung may kailangan ka pang malaman tungkol sa iClimate.'
                    : "You're welcome! Ask me anytime about weather, yield, planting, advisories, or your iClimate account.";
            }

            return str_contains($language, 'Tagalog')
                ? 'Kumusta! Ako si Climora AI, ang iClimate rice guidance assistant. Puwede kang magtanong tungkol sa panahon, ani, pagtatanim, irigasyon, advisory, o sistema.'
                : 'Hello! I am Climora AI, the iClimate rice guidance assistant. Ask me about weather, yield, planting, irrigation, advisories, or how to use the system.';
        }

        if ($intent === IntentDetectionService::SYSTEM_HELP && str($text)->contains(['weather', 'forecast', 'prediction'])) {
            return str_contains($language, 'Tagalog')
                ? 'Kinukuha ng iClimate ang weather inputs mula sa latest Open-Meteo forecast kapag available, at gumagamit din ng naka-save na climate records sa system bilang fallback o context. Pagkatapos, ipinapasa ang rainfall, temperature, humidity, wind speed, season, farm type, at farm area sa Predict.py/Python model at iClimate decision rules. Kung hindi maabot ang Python Farming AI API, gumagamit ang system ng local fallback rules para makapagbigay pa rin ng guidance. Hindi ako gumagawa ng sariling raw weather data; ipinapaliwanag at inaayos ko ang datos mula sa mga tool ng iClimate.'
                : 'iClimate gathers weather inputs from the latest Open-Meteo forecast when available, then uses saved climate records in the system as fallback or context. It passes rainfall, temperature, humidity, wind speed, season, farm type, and farm area into Predict.py/Python models and iClimate decision rules. If the Python Farming AI API cannot be reached, the system uses local fallback rules so guidance is still available. I do not create raw weather data myself; I explain and organize the data from iClimate tools.';
        }

        if ($intent === IntentDetectionService::FARMING_ADVISORY || str_contains($text, 'fertilizer')) {
            return str_contains($language, 'Tagalog')
                ? 'Para sa payong pangsakahan sa iClimate, gamitin ang weather prediction, rice yield result, at field condition bago magdesisyon. Kung fertilizer ang tanong, mas mabuting basehan ang soil test, crop stage, at inaasahang ulan.'
                : 'For iClimate farming advice, use the weather prediction, rice yield result, and actual field condition together. For fertilizer, base the decision on soil test results, crop stage, and expected rainfall.';
        }

        if ($intent === IntentDetectionService::GENERAL_AGRICULTURE || str_contains($text, 'rice') || str_contains($text, 'palay')) {
            return str_contains($language, 'Tagalog')
                ? 'Makakatulong ako sa rice farming kapag konektado ito sa iClimate, gaya ng ulan, ani, pagtatanim, patubig, climate risk, at advisory.'
                : 'I can help with rice farming when it is connected to iClimate, such as rainfall, yield, planting, irrigation, climate risk, and advisories.';
        }

        return str_contains($language, 'Tagalog')
            ? 'Naiintindihan ko ang tanong pero wala pa akong partikular na sagot na naka-save dito. Subukan ulit nang mas detalyado, o kumpirmahin sa MAO o IT staff.'
            : 'I understand the topic, but I do not have a specific saved answer for that yet. Try rephrasing with more detail, or confirm with your MAO or IT staff.';
    }

    private function textResponse(string $answer, string $intent, string $language, array $memory, float $startedAt, array $metadata): array
    {
        $confidence = (float) ($metadata['confidence_score'] ?? 65);
        $sourceType = (string) ($metadata['source_type'] ?? 'Knowledge Base');
        $sourceName = (string) ($metadata['source_name'] ?? $sourceType);

        return [
            'intent' => $intent,
            'answer' => $this->cleanVisibleAnswer($answer),
            'source_type' => $sourceType,
            'source_name' => $sourceName,
            'source_url' => $metadata['source_url'] ?? null,
            'source_credit' => $metadata['source_credit'] ?? ('Source: '.$sourceName),
            'language' => $language,
            'memory' => [
                ...$memory,
                'last_answer_source' => $sourceType,
                'last_answer_intent' => $intent,
            ],
            'prediction_result' => [
                'intent_detection' => $metadata['intent_detection'] ?? null,
                'knowledge_base_id' => $metadata['knowledge_base_id'] ?? null,
                'generative_ai' => $metadata['generative_ai'] ?? null,
                'answer_source' => isset($metadata['generative_ai'])
                    ? 'Answered by Groq using the Climora AI iClimate instructions.'
                    : 'Answered from iClimate system knowledge, saved records, or built-in rules.',
                'source_credit' => $metadata['source_credit'] ?? ('Source: '.$sourceName),
            ],
            'weather_prediction' => null,
            'rice_yield_prediction' => null,
            'planting_recommendation' => null,
            'irrigation_recommendation' => null,
            'warnings' => [],
            'explanation' => $this->isTagalog($language)
                ? 'Ang tanong ay na-classify bilang '.$intent.' at sinagot mula sa '.$sourceType.'.'
                : 'Question classified as '.$intent.' and answered from '.$sourceType.'.',
            'confidence_score' => $confidence,
            'response_time_ms' => (int) round((microtime(true) - $startedAt) * 1000),
        ];
    }

    private function cleanVisibleAnswer(string $answer): string
    {
        $answer = trim($answer);

        $answer = preg_replace('/\A\s*Answer:\s*/i', '', $answer) ?? $answer;
        $answer = preg_replace('/\n{2,}(Explanation|Recommendation|Warning|Source|Confidence):[\s\S]*\z/i', '', $answer) ?? $answer;

        return trim($answer);
    }

    private function detectIntent(string $question, array $memory): string
    {
        $text = str($question)->lower()->toString();
        $scores = [
            'planting' => $this->score($text, ['plant', 'planting', 'seedling', 'seedlings', 'transplant', 'sow', 'punla', 'tanim', 'magtanim', 'next week']),
            'irrigation' => $this->score($text, ['irrigat', 'water', 'tubig', 'patubig', 'dilig', 'canal', 'rainfed', 'irrigated']),
            'yield' => $this->score($text, ['yield', 'harvest', 'production', 'ani', 'tons', 'low yield', 'palay']),
            'weather' => $this->score($text, ['rain', 'weather', 'storm', 'wind', 'ulan', 'bagyo', 'hangin', 'humidity', 'temperature']),
            'warning' => $this->score($text, ['drought', 'flood', 'warning', 'heat', 'risk', 'tagtuyot', 'baha', 'init', 'water shortage']),
            'fertilizer' => $this->score($text, ['fertilizer', 'fertiliser', 'soil', 'nitrogen', 'urea', 'compost', 'abono', 'pataba', 'soil test']),
            'pest_disease' => $this->score($text, ['pest', 'disease', 'insect', 'fungus', 'blast', 'tungro', 'brown spot', 'planthopper', 'sakit', 'peste']),
        ];

        arsort($scores);
        $intent = (string) array_key_first($scores);

        if (($scores[$intent] ?? 0) === 0 && str($text)->contains(['it', 'that', 'this', 'also', 'what about'])) {
            return (string) ($memory['last_intent'] ?? 'general');
        }

        return ($scores[$intent] ?? 0) > 0 ? $intent : 'general';
    }

    private function numbersFrom(string $question): array
    {
        $values = [];

        if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mm|millimeter|millimeters)/i', $question, $match)) {
            $values['rainfall'] = (float) $match[1];
        }

        if (preg_match('/(\d+(?:\.\d+)?)\s*(?:c|degree|degrees|celsius)/i', $question, $match)) {
            $values['temperature'] = (float) $match[1];
        }

        if (preg_match('/(\d+(?:\.\d+)?)\s*(?:ha|hectare|hectares)/i', $question, $match)) {
            $values['area'] = (float) $match[1];
        }

        if (preg_match('/(?:humidity|halumigmig)\s*(?:is|:)?\s*(\d+(?:\.\d+)?)\s*%?/i', $question, $match)) {
            $values['humidity'] = (float) $match[1];
        }

        if (preg_match('/(?:wind|hangin|wind speed)\s*(?:is|:)?\s*(\d+(?:\.\d+)?)/i', $question, $match)) {
            $values['wind_speed'] = (float) $match[1];
        }

        if (preg_match('/(?:range|temp range)\s*(?:is|:)?\s*(\d+(?:\.\d+)?)/i', $question, $match)) {
            $values['temp_range'] = (float) $match[1];
        }

        return $values;
    }

    private function conditionsFrom(string $question): array
    {
        $text = str($question)->lower()->toString();
        $conditions = [];

        if (str_contains($text, 'rainfed') || str_contains($text, 'walang irigasyon')) {
            $conditions['farm_type'] = FarmerProfile::FARM_TYPE_RAINFED;
        } elseif (str_contains($text, 'irrigated') || str_contains($text, 'may irigasyon')) {
            $conditions['farm_type'] = FarmerProfile::FARM_TYPE_IRRIGATED;
        }

        if (str_contains($text, 'dry season') || str_contains($text, 'tag-init')) {
            $conditions['season'] = ClimateRecord::SEASON_DRY;
        } elseif (str_contains($text, 'wet season') || str_contains($text, 'tag-ulan')) {
            $conditions['season'] = ClimateRecord::SEASON_WET;
        }

        if (str_contains($text, 'very hot') || str_contains($text, 'sobrang init')) {
            $conditions['temperature'] = 35;
        }

        return $conditions;
    }

    private function sourceNotes(array $numbers, array $conditions, CarbonImmutable $targetMonth): array
    {
        $notes = [];

        foreach (['rainfall', 'temperature', 'humidity', 'wind_speed', 'area'] as $field) {
            if (array_key_exists($field, $numbers)) {
                $notes[] = str_replace('_', ' ', $field).' came from the farmer question.';
            }
        }

        foreach (['farm_type', 'season'] as $field) {
            if (array_key_exists($field, $conditions)) {
                $notes[] = str_replace('_', ' ', $field).' came from the farmer question.';
            }
        }

        $notes[] = 'Missing weather values used the iClimate Random Forest model prediction for '.$targetMonth->format('F Y').'.';

        return $notes;
    }

    private function normalizeWarnings(array $pythonWarnings, array $decision): array
    {
        $warnings = [];

        foreach ($pythonWarnings as $warning) {
            $warnings[] = is_array($warning) ? $warning : ['title' => $warning, 'reason' => $warning];
        }

        foreach ($decision['notifications'] as $notification) {
            $warnings[] = ['title' => $notification, 'reason' => $notification];
        }

        return array_values(array_unique($warnings, SORT_REGULAR));
    }

    private function predictionQuality(array $context, array $yield, ?string $apiError): array
    {
        $issues = [];

        if ($apiError) {
            $issues[] = 'The trained yield model gave no result, so this advice uses weather rules only and has no yield estimate.';
        }

        if (is_numeric($context['rainfall']) && ((float) $context['rainfall'] < 0 || (float) $context['rainfall'] > 600)) {
            $issues[] = 'Rainfall is outside the normal model planning range.';
        }

        if (is_numeric($context['temp_avg']) && ((float) $context['temp_avg'] < 18 || (float) $context['temp_avg'] > 40)) {
            $issues[] = 'Temperature is outside the normal model planning range.';
        }

        if (is_numeric($context['humidity']) && ((float) $context['humidity'] < 35 || (float) $context['humidity'] > 100)) {
            $issues[] = 'Humidity is outside the normal model planning range.';
        }

        if ((float) $context['area'] <= 0) {
            $issues[] = 'Farm area is missing or invalid.';
        }

        $score = max(35, min(95, 100 - (count($issues) * 12)));

        return [
            'score' => $score,
            'label' => match (true) {
                $score >= 82 => 'High reliability',
                $score >= 65 => 'Moderate reliability',
                default => 'Low reliability',
            },
            'issues' => $issues,
        ];
    }

    private function adjustedConfidence(array $yield, array $decision, array $quality): float
    {
        $base = (float) ($yield['confidence'] ?? $decision['confidence']['value'] ?? 65);
        $confidence = ($base * 0.65) + ((float) $quality['score'] * 0.35);

        return round(max(35, min(95, $confidence)), 2);
    }

    private function insights(string $intent, array $context, array $yield, array $decision, array $warnings, array $quality, string $language): array
    {
        $tagalog = $this->isTagalog($language);
        $yieldValue = Arr::get($yield, 'predicted_yield');
        $steps = [];
        $reasons = [];

        foreach ($decision['stress_factors'] as $factor) {
            $reasons[] = $tagalog
                ? $this->tagalogStressLabel((string) $factor['label']).': '.$this->tagalogPhrase((string) $factor['detail'])
                : $factor['label'].': '.$factor['detail'];
        }

        if ($warnings !== []) {
            $steps[] = $tagalog ? 'Suriin ang bukid pagkatapos ng ulan at panatilihing bukas ang drainage channels.' : 'Check the field after rainfall and keep drainage channels open.';
        }

        if (is_numeric($context['rainfall']) && (float) $context['rainfall'] < 100) {
            $steps[] = $tagalog ? 'Para sa rainfed na bukid, ipagpaliban muna ang paglilipat-tanim hanggang bumuti ang ulan o makahanap ng dagdag na patubig.' : 'For rainfed fields, delay transplanting until rainfall improves or arrange supplemental water.';
        }

        if (is_numeric($context['rainfall']) && (float) $context['rainfall'] > 300) {
            $steps[] = $tagalog ? 'Iwasan muna ang dagdag na tubig at tingnan ang mabababang bahagi kung may waterlogging.' : 'Avoid adding more water and inspect low areas for waterlogging.';
        }

        if (is_numeric($context['temp_avg']) && (float) $context['temp_avg'] >= 34) {
            $steps[] = $tagalog ? 'Magpatubig sa umaga o late afternoon para mabawasan ang heat stress.' : 'Schedule irrigation early morning or late afternoon to reduce heat stress.';
        }

        if ($yieldValue !== null && (float) $yieldValue < 3) {
            $steps[] = $tagalog ? 'Mag-request ng soil testing at repasuhin ang timing ng fertilizer bago ang susunod na crop stage.' : 'Request soil testing and review fertilizer timing before the next crop stage.';
        }

        if ($intent === IntentDetectionService::FARMING_ADVISORY) {
            $steps[] = $tagalog ? 'Unahin ang soil-test results; kung wala pa, hatiin ang nitrogen application imbes na isang bagsakan.' : 'Use soil-test results first; if unavailable, split nitrogen applications instead of applying all at once.';
            $steps[] = $tagalog ? 'Iwasang maglagay ng fertilizer bago ang malakas na ulan dahil puwedeng maanod ang nutrients.' : 'Avoid fertilizer application before heavy rain because nutrients can be washed away.';
            $steps[] = $tagalog ? 'Suriin ang dahon dalawang beses kada linggo pagkatapos ng ulan o mataas na humidity, at i-report ang paninilaw, spots, o kumpol ng insekto.' : 'Inspect leaves twice a week after rain or high humidity and report unusual yellowing, spots, or insect clusters.';
            $steps[] = $tagalog ? 'Iwasan ang hindi kailangang pesticide hangga\'t hindi pa natutukoy ang peste o sakit.' : 'Avoid unnecessary pesticide use until the pest or disease is identified.';
        }

        if ($steps === []) {
            $steps[] = $tagalog ? 'Ipagpatuloy ang regular na pagmamasid sa bukid at ikumpara ang payo sa aktuwal na kondisyon.' : 'Continue normal field monitoring and compare the advice with actual field condition.';
        }

        if ($quality['issues'] !== []) {
            $steps[] = $tagalog ? 'Para mas tumama ang susunod na prediction, magdagdag ng recent climate records at rice production results pagkatapos ng ani.' : 'Improve accuracy by adding recent climate records and rice production outcomes after harvest.';
        }

        return [
            'reasons' => array_values(array_unique($reasons)),
            'next_steps' => array_values(array_unique($steps)),
            'quality' => $quality,
            'input_summary' => $tagalog
                ? 'Ulan '.$this->fmtNumber($context['rainfall'], 1, ' mm').', temperatura '.$this->fmtNumber($context['temp_avg'], 1, ' C').', humidity '.$this->fmtNumber($context['humidity'], 1, '%').', hangin '.$this->fmtNumber($context['wind_speed'], 1).', '.($context['season'] ?? 'hindi alam ang').' season, '.$context['farm_type'].' na bukid.'
                : 'Rainfall '.$this->fmtNumber($context['rainfall'], 1, ' mm').', temperature '.$this->fmtNumber($context['temp_avg'], 1, ' C').', humidity '.$this->fmtNumber($context['humidity'], 1, '%').', wind '.$this->fmtNumber($context['wind_speed'], 1).', '.($context['season'] ?? 'unknown').' season, '.$context['farm_type'].' farm.',
        ];
    }

    /** A missing value reads "not available", never "0.0". */
    private function fmtNumber(mixed $value, int $decimals, string $unit = ''): string
    {
        return is_numeric($value) ? number_format((float) $value, $decimals).$unit : 'not available';
    }

    private function explanation(array $weather, array $yield, array $insights, ?string $apiError, string $language): string
    {
        $tagalog = $this->isTagalog($language);
        $parts = [];
        $parts[] = $tagalog ? 'Sinuri ko ang tanong gamit ang mga input na ito: '.$insights['input_summary'] : 'I checked the question against these inputs: '.$insights['input_summary'];
        $yieldPhrase = ($yield['fallback'] ?? false) === true
            ? (isset($yield['predicted_yield']) && $yield['predicted_yield'] !== null
                ? ($tagalog ? 'gumamit ng fallback estimate na ' : 'used a fallback estimate of ').number_format((float) $yield['predicted_yield'], 2).' tons/hectare'
                : ($tagalog ? 'gumamit ng fallback estimate pero walang numeric value' : 'used fallback rules but did not produce a numeric value'))
            : (isset($yield['predicted_yield']) && $yield['predicted_yield'] !== null
                ? ($tagalog ? 'nag-estimate ng ' : 'estimated ').number_format((float) $yield['predicted_yield'], 2).' tons/hectare'
                : ($tagalog ? 'walang naibalik na numeric yield estimate' : 'did not return a numeric yield estimate'));

        $parts[] = $tagalog
            ? 'Ayon sa weather model, '.$this->weatherLabel($weather['predicted_weather'] ?? null, $language).' ang kondisyon; ang yield model naman ay '.$yieldPhrase.'.'
            : 'The weather model indicates '.$weather['predicted_weather'].', while the yield model '.$yieldPhrase.'.';
        $parts[] = $tagalog ? 'Sinuri rin ng decision rules ang tagtuyot, malakas na ulan, init, humidity, pangangailangan sa patubig, inaasahang ani, at stress factors bago pumili ng rekomendasyon.' : 'The decision rules checked drought, heavy rainfall, heat, humidity, irrigation need, expected yield, and stress factors before choosing the recommendation.';

        if ($insights['reasons'] !== []) {
            $parts[] = ($tagalog ? 'Pangunahing dahilan: ' : 'Main reason: ').implode(' ', array_slice($insights['reasons'], 0, 2));
        }

        $parts[] = $tagalog
            ? 'Reliability: '.$this->qualityLabel((string) $insights['quality']['label'], $language).' na may score na '.$insights['quality']['score'].'.'
            : 'Reliability: '.$insights['quality']['label'].' with score '.$insights['quality']['score'].'.';

        if ($apiError) {
            $parts[] = $tagalog ? 'Tandaan: '.$apiError.' Gumamit ng local decision-support fallback rules kung walang model output.' : 'Note: '.$apiError.' Local decision-support fallback rules were used where model output was unavailable.';
        }

        return implode(' ', $parts);
    }

    private function composeAnswer(string $intent, array $weather, array $yield, array $decision, array $warnings, array $insights, string $explanation, string $source, float $confidence, string $language): string
    {
        $tagalog = $this->isTagalog($language);
        $yieldText = isset($yield['predicted_yield']) && $yield['predicted_yield'] !== null
            ? number_format((float) $yield['predicted_yield'], 2).' tons/hectare'
            : ($tagalog ? 'hindi available' : 'not available');
        $totalText = isset($yield['estimated_total_production_tons']) && $yield['estimated_total_production_tons'] !== null
            ? number_format((float) $yield['estimated_total_production_tons'], 2).' tons'
            : null;
        $warningText = $warnings === []
            ? ($tagalog ? 'Walang urgent climate warning na nabuo.' : 'No urgent climate warning was generated.')
            : collect($warnings)->pluck('title')->implode('; ');
        $weatherText = $this->weatherLabel($weather['predicted_weather'] ?? null, $language);
        $riskText = $this->riskLabel((string) $decision['risk']['label'], $language);
        $qualityText = $this->qualityLabel((string) $insights['quality']['label'], $language);

        if ($tagalog) {
            $opening = match ($intent) {
                IntentDetectionService::PLANTING_RECOMMENDATION => 'Para sa pagtatanim, ito ang rekomendasyon ko: '.$this->tagalogPhrase((string) $decision['planting']['recommendation']),
                IntentDetectionService::IRRIGATION_RECOMMENDATION => 'Para sa patubig, ito ang rekomendasyon ko: '.$this->tagalogPhrase((string) $decision['irrigation']['recommendation']),
                IntentDetectionService::RICE_YIELD_PREDICTION => 'Ang predicted rice yield mo ay '.$yieldText.($totalText ? ', at ang estimated total production ay '.$totalText : '').'. '.$this->tagalogPhrase((string) $decision['yield']['advisory']),
                IntentDetectionService::WEATHER_PREDICTION => 'Ang predicted weather ay '.$weatherText.'.',
                IntentDetectionService::CLIMATE_RISK => 'Climate warning check: '.$warningText,
                IntentDetectionService::FARMING_ADVISORY => 'Para sa payong pangsakahan, magsimula sa pagmamasid sa bukid at itugma ang fertilizer, peste, o soil decisions sa predicted climate conditions. '.$this->tagalogPhrase((string) $decision['yield']['advisory']),
                default => 'Narito ang payong pangsakahan batay sa latest climate data at model results.',
            };
        } else {
            $opening = match ($intent) {
                IntentDetectionService::PLANTING_RECOMMENDATION => 'For planting, I recommend: '.$decision['planting']['recommendation'],
                IntentDetectionService::IRRIGATION_RECOMMENDATION => 'For irrigation, I recommend: '.$decision['irrigation']['recommendation'],
                IntentDetectionService::RICE_YIELD_PREDICTION => 'Your predicted rice yield is '.$yieldText.($totalText ? ', with estimated total production of '.$totalText : '').'. '.$decision['yield']['advisory'],
                IntentDetectionService::WEATHER_PREDICTION => 'The predicted weather is '.$weather['predicted_weather'].'.',
                IntentDetectionService::CLIMATE_RISK => 'Climate warning check: '.$warningText,
                IntentDetectionService::FARMING_ADVISORY => 'For farming advice, start with field monitoring and match fertilizer, pest, or soil decisions with the predicted climate conditions. '.$decision['yield']['advisory'],
                default => 'Here is the farming guidance based on the latest climate and model results.',
            };
        }

        $nextSteps = collect($insights['next_steps'])
            ->take(4)
            ->map(fn (string $step, int $index): string => ($index + 1).'. '.$step)
            ->implode("\n");

        if ($tagalog) {
            return "{$opening}\n\n".
                'Mga input na ginamit: '.$insights['input_summary']."\n".
                'Predicted Weather: '.$weatherText."\n".
                'Predicted Yield: '.$yieldText."\n".
                ($totalText ? 'Estimated Total Production: '.$totalText."\n" : '').
                'Risk Level: '.$riskText.' (score '.$decision['score']['value'].")\n".
                'Prediction Reliability: '.$qualityText.' ('.$insights['quality']['score'].")\n".
                $explanation."\n\n".
                "Rekomendasyon:\n".
                'Pagtatanim: '.$this->tagalogPhrase((string) $decision['planting']['recommendation'])."\n".
                'Patubig: '.$this->tagalogPhrase((string) $decision['irrigation']['recommendation'])."\n".
                "Susunod na hakbang:\n".$nextSteps."\n\n".
                "Babala: {$warningText}";
        }

        return "{$opening}\n\n".
            'Inputs used: '.$insights['input_summary']."\n".
            'Predicted Weather: '.$weather['predicted_weather']."\n".
            'Predicted Yield: '.$yieldText."\n".
            ($totalText ? 'Estimated Total Production: '.$totalText."\n" : '').
            'Risk Level: '.$decision['risk']['label'].' (score '.$decision['score']['value'].")\n".
            'Prediction Reliability: '.$insights['quality']['label'].' ('.$insights['quality']['score'].")\n".
            $explanation."\n\n".
            "Recommendation:\n".
            'Planting: '.$decision['planting']['recommendation']."\n".
            'Irrigation: '.$decision['irrigation']['recommendation']."\n".
            "Next steps:\n".$nextSteps."\n\n".
            "Warning: {$warningText}";
    }

    private function isTagalog(string $language): bool
    {
        return str_contains($language, 'Tagalog');
    }

    private function weatherLabel(?string $weather, string $language): string
    {
        if (! $this->isTagalog($language)) {
            return (string) $weather;
        }

        return match (strtolower((string) $weather)) {
            'heavy rain' => 'malakas na ulan',
            'rain' => 'maulan',
            'dry' => 'tuyo o mababa ang ulan',
            'cloudy' => 'maulap',
            default => (string) $weather,
        };
    }

    private function riskLabel(string $label, string $language): string
    {
        if (! $this->isTagalog($language)) {
            return $label;
        }

        return match (strtolower($label)) {
            'severe risk' => 'Matinding Panganib',
            'high risk' => 'Mataas na Panganib',
            'moderate risk', 'medium risk' => 'Katamtamang Panganib',
            'low risk' => 'Mababang Panganib',
            default => $label,
        };
    }

    private function qualityLabel(string $label, string $language): string
    {
        if (! $this->isTagalog($language)) {
            return $label;
        }

        return match (strtolower($label)) {
            'high reliability' => 'Mataas ang reliability',
            'moderate reliability' => 'Katamtaman ang reliability',
            'low reliability' => 'Mababa ang reliability',
            default => $label,
        };
    }

    private function tagalogStressLabel(string $label): string
    {
        return match (strtolower($label)) {
            'rainfall' => 'Ulan',
            'temperature' => 'Temperatura',
            'humidity' => 'Humidity',
            'yield' => 'Ani',
            'irrigation' => 'Patubig',
            default => $label,
        };
    }

    private function tagalogPhrase(string $text): string
    {
        $phrases = [
            'Proceed with planting' => 'Puwedeng magtanim',
            'Delay planting' => 'Ipagpaliban muna ang pagtatanim',
            'Plant with caution' => 'Magtanim nang may pag-iingat',
            'Irrigation not required' => 'Hindi kailangan ang patubig ngayon',
            'Irrigate immediately' => 'Magpatubig agad',
            'Prepare supplemental irrigation' => 'Maghanda ng karagdagang patubig',
            'Maintain normal irrigation' => 'Panatilihin ang normal na patubig',
            'Expected yield is favorable.' => 'Maganda ang inaasahang ani.',
            'Expected yield is low; review inputs and field condition.' => 'Mababa ang inaasahang ani; suriin ang inputs at kondisyon ng bukid.',
            'Expected yield is moderate.' => 'Katamtaman ang inaasahang ani.',
        ];

        return $phrases[$text] ?? $text;
    }

    private function score(string $text, array $keywords): int
    {
        $score = 0;

        foreach ($keywords as $keyword) {
            if (str_contains($text, $keyword)) {
                $score++;
            }
        }

        return $score;
    }
}
