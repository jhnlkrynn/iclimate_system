<?php

namespace App\Http\Requests;

use App\Models\User;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProfileUpdateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'string',
                'lowercase',
                'email',
                'max:255',
                Rule::unique(User::class)->ignore($this->user()->id),
            ],
            'contact_number' => ['nullable', 'string', 'max:50'],
            'address' => ['nullable', 'string'],
            'barangay' => ['nullable', 'string', 'max:255', \Illuminate\Validation\Rule::in(\App\Support\LianBarangays::all())],
            // Farmers keep their farm size and type here (the dashboard pop-ups were removed in 2026-10).
            'farm_area' => ['nullable', 'numeric', 'gt:0', 'max:'.config('farms.max_hectares', 10000), 'decimal:0,2'],
            'farm_type' => ['nullable', 'string', Rule::in(\App\Models\FarmerPlantingSchedule::FARM_TYPES)],
            // Panel revision 1.1: every farmer organization the farmer belongs to.
            'farmer_organization_ids' => ['nullable', 'array'],
            'farmer_organization_ids.*' => ['integer', 'exists:farmer_organizations,id'],
        ];
    }
}
